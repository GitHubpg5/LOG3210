class SimulationError(Exception):
    pass
